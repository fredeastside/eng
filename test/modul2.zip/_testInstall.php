<?php
class _pattern extends fmakeCore{
	
}